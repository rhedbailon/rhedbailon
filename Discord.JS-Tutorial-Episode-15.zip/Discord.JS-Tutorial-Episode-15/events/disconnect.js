const Discord = require("discord.js")
const prefix = require("../botconfig.json")


module.exports = bot => {
    console.log(`you have been disconnected at ${new Date()}.`)
}